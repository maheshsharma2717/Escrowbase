Please follow the Instruction v-2.0

1.In Settings.INI file you can point the Server Path.
2.Use the correct CSV file with "" and ; seperated (like="Escrow";"9876543210";etc).