Welcome TO EscrowBase Application Logins

Instruction To Use 

1.Open EscrowBase.exe
2.Open EscrowBase.exe.config & Check Url
3.Add Username And Password (if Empty or want to change )
4.Press Save Button to Save (it will create new file savedata.txt in which your username and password will be saved Or Change Existing data)
5.Press Web LogIn Button 

It will reduct you to the website and if username password correct you are logged in automatically


Follow Up These Steps 
Thankyou